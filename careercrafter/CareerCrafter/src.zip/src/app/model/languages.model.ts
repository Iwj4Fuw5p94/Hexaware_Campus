// languages.model.ts

export interface Languages {
    languageId: number;
    languageName: string;
  }
  