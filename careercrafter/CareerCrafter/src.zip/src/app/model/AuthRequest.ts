export interface AuthInfo{
    username:string;
    password:string;
}