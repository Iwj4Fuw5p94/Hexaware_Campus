// skills.model.ts

export interface Skills {
    skillId: number;
    skillName: string;
  }
  