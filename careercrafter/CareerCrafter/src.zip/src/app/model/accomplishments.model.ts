export interface Accomplishments{
    accomplishmentId:Number;
    description:string;
}