// reference-links.model.ts

export interface ReferenceLinks {
    linkId: number;
    link: string;
  }
  